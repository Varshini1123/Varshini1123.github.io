import machine
import time
import network
import dht
import urequests

# DHT22 data pin connected to GPIO5 (D1)
dht_pin = machine.Pin(23)
# IR sensor pin
ir_pin = machine.Pin(15)
# WiFi credentials
ssid = "Wokwi-GUEST"
password = ""
# ThingSpeak API key
api_key = "R4PC4HW83LV9O3KE"
# ThingSpeak server
ts_server = "api.thingspeak.com"
channel_number = 2319907

# Connect to WiFi
def connect_wifi():
    sta_if = network.WLAN(network.STA_IF)
    if not sta_if.isconnected():
        print("Connecting to WiFi...")
        sta_if.active(True)
        sta_if.connect(ssid, password)
        while not sta_if.isconnected():
            pass
        print("Connected to WiFi")

# Function to read and return temperature, humidity, and IR data
def read_sensors():
    dht22 = dht.DHT22(dht_pin)  # Create the DHT22 object
    dht22.measure()
    temp, hum = dht22.temperature(), dht22.humidity()
    ir_data = ir_pin.value()  # Read IR data
    return temp, hum, ir_data

# Send data to ThingSpeak
def send_to_thingspeak(temp, hum, ir_data):
    base_url = "http://{}/update?api_key={}&field1={}&field2={}&field3={}".format(
        ts_server, api_key, temp, hum, ir_data)
    response = urequests.get(base_url)
    if response.status_code == 200:
        print("Data sent to ThingSpeak successfully")
    else:
        print("Failed to send data to ThingSpeak")

# Main program
def main():
    connect_wifi()
    while True:
        temp, hum, ir_data = read_sensors()
        print("Temperature: {}°C, Humidity: {}%, IR Data: {}".format(temp, hum, ir_data))
        send_to_thingspeak(temp, hum, ir_data)
        time.sleep(300)  # Send data every 5 minutes

if __name__ == '__main__':
    main()